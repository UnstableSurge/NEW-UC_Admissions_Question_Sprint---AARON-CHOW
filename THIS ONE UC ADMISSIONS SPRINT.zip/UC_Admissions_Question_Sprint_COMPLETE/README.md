# UC Admissions Data Challenge — Complete GitHub Repo

This repository contains the Pandas notebook and challenge CSV data for Questions 1–10.

## Question 1 update

The Fall 2025 campus application totals supplied by the user are:

- UC Berkeley: 19,531
- UC Davis: 20,856
- UC Irvine: 17,756
- UC Los Angeles: 18,516
- UC Merced: 10,588
- UC Riverside: 11,648
- UC San Diego: 18,847
- UC Santa Barbara: 17,846
- UC Santa Cruz: 16,167

Total campus applications = **151,755**

Systemwide unique applicants = **26,457**

Therefore:

`151,755 / 26,457 = 5.735911...`

Rounded to two decimals: **5.74**

## Final answer list

1. 5.74
2. 8.29%
3. UC Davis
4. 0.09
5. 9
6. Hispanic/Latino(a)
7. 34.04%
8. 99.06%
9. 193
10. MISSION SENIOR HIGH SCHOOL

## Running the notebook

Upload the repository to GitHub or open the notebook in Google Colab. The CSV files are kept under `Data/`.
